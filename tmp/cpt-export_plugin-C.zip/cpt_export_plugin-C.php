<?php
/**
 * Plugin Name: CPT Export
 * Description: Export Custom Post Types to XML format with date range, author, and status filtering. Optionally delete after export.
 * Version: 1.0.90
 * Author: Mulli Bahr & AI
 * Author URI: https://site2goal.co.il
 * Text Domain: cpt-export
 * Domain Path: /languages
 * Requires PHP: 7.4
 * 
 * Shortcode Usage:
 * [cpt_export post_type="product" author="1" status="publish" start_date="2024-01-01" end_date="2024-12-31" delete="1" permanent="1" download="1"]
 * 
 * Shortcode Parameters:
 * - post_type (required): The post type to export (e.g., "post", "page", "product")
 * - author (optional): User ID of the author to filter by
 * - status (optional): Post status to filter by ("publish", "draft", "private", "pending", "future")
 * - start_date (optional): Start date in YYYY-MM-DD format
 * - end_date (optional): End date in YYYY-MM-DD format
 * - delete (optional): "1" to delete posts after export, "0" to export only (default: "0")
 * - permanent (optional): "1" to permanently delete (bypass trash), "0" to move to trash (default: "0")
 * - delete_media (optional): "1" to delete attached media permanently, "0" to preserve media (default: "0")
 * - save_folder (optional): Folder name in uploads directory to save file, empty to download (default: "")
 * - compress (optional): "1" to create ZIP file, "0" for XML only (default: "0")
 * - download (optional): "1" to trigger download, "0" to return message (default: "1")
 * - return_data (optional): "1" to return XML content as text, "0" for normal operation (default: "0")
 * 
 * Examples:
 * [cpt_export post_type="product"] - Export all products
 * [cpt_export post_type="post" author="1" status="publish"] - Export published posts by author ID 1
 * [cpt_export post_type="event" start_date="2024-01-01" end_date="2024-12-31"] - Export events from 2024
 * [cpt_export post_type="reports" save_folder="monthly_exports" compress="1"] - Save compressed file to uploads/monthly_exports/ folder
 * [cpt_export post_type="old_data" delete="1" permanent="1" delete_media="1"] - Export and permanently delete old data with media
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Check PHP version compatibility
if (version_compare(PHP_VERSION, '7.4', '<')) {
    add_action('admin_notices', function () {
        echo '<div class="notice notice-error"><p>' .
            sprintf(__('CPT Export requires PHP 7.4 or higher. You are running PHP %s.', 'cpt-export'), PHP_VERSION) .
            '</p></div>';
    });
    return;
}

class CPT_Export_Tool
{

    public function __construct()
    {
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'handle_export'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('cpt_export', array($this, 'shortcode_handler'));
    }

    public function load_textdomain()
    {
        // Try to load from plugin languages directory first
        $plugin_rel_path = dirname(plugin_basename(__FILE__)) . '/languages';
        $loaded = load_plugin_textdomain('cpt-export', false, $plugin_rel_path);

        // If not loaded, try from WP languages directory
        if (!$loaded) {
            $wp_lang_dir = WP_LANG_DIR . '/plugins/';
            if (file_exists($wp_lang_dir . 'cpt-export-' . get_locale() . '.mo')) {
                load_textdomain('cpt-export', $wp_lang_dir . 'cpt-export-' . get_locale() . '.mo');
            }
        }
    }

    public function add_admin_menu()
    {
        add_management_page(
            __('CPT Export Tool', 'cpt-export'),
            __('CPT Export', 'cpt-export'),
            'export',
            'cpt-export-tool',
            array($this, 'admin_page')
        );
    }

    public function enqueue_scripts($hook)
    {
        if ($hook !== 'tools_page_cpt-export-tool') {
            return;
        }

        wp_enqueue_script('jquery');
    }

    public function admin_page()
    {
        // Display success message if file was saved
        if (isset($_GET['saved']) && $_GET['saved'] === '1') {
            $file_path = urldecode($_GET['file_path']);
            $count = intval($_GET['count']);
            $compressed = isset($_GET['compressed']) && $_GET['compressed'] === '1';
            $uploads_dir = wp_upload_dir();
            $full_url = $uploads_dir['baseurl'] . '/' . $file_path;

            echo '<div class="notice notice-success is-dismissible">';
            echo '<p><strong>' . __('Export Successful!', 'cpt-export') . '</strong></p>';
            echo '<p>' . sprintf(__('Successfully exported %d posts.', 'cpt-export'), $count) . '</p>';
            if ($compressed) {
                echo '<p>' . sprintf(__('Compressed file saved to: %s', 'cpt-export'), '<code>' . esc_html($file_path) . '</code>') . '</p>';
            } else {
                echo '<p>' . sprintf(__('File saved to: %s', 'cpt-export'), '<code>' . esc_html($file_path) . '</code>') . '</p>';
            }
            echo '<p><a href="' . esc_url($full_url) . '" target="_blank" class="button button-secondary">' . __('Download File', 'cpt-export') . '</a></p>';
            echo '</div>';
        }

        ?>
        <div class="wrap">
            <h1><?php _e('Export Custom Post Types', 'cpt-export'); ?></h1>
            <p><?php _e('When you click the button below WordPress will create an XML file for you to save to your computer.', 'cpt-export'); ?>
            </p>
            <p><?php _e('This format, which is called WordPress eXtended RSS or WXR, will contain your posts, custom fields, categories, and other content.', 'cpt-export'); ?>
            </p>

            <form method="post" id="cpt-export-form">
                <?php wp_nonce_field('cpt_export_nonce', 'cpt_export_nonce'); ?>

                <h3><?php _e('Choose what to export', 'cpt-export'); ?></h3>

                <table class="form-table" role="presentation">
                    <tbody>
                        <tr>
                            <th scope="row">
                                <label for="cpt_post_type"><?php _e('Post Type', 'cpt-export'); ?></label>
                            </th>
                            <td>
                                <select name="cpt_post_type" id="cpt_post_type" required>
                                    <option value=""><?php _e('Select a post type...', 'cpt-export'); ?></option>
                                    <?php
                                    $post_types = get_post_types(array('public' => true), 'objects');
                                    foreach ($post_types as $post_type) {
                                        if ($post_type->name !== 'attachment') {
                                            echo '<option value="' . esc_attr($post_type->name) . '">' . esc_html($post_type->label) . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                                <p class="description"><?php _e('Select the post type you want to export.', 'cpt-export'); ?>
                                </p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="cpt_author"><?php _e('Author', 'cpt-export'); ?></label>
                            </th>
                            <td>
                                <select name="cpt_author" id="cpt_author">
                                    <option value=""><?php _e('All authors', 'cpt-export'); ?></option>
                                    <?php
                                    $authors = get_users(array(
                                        'capability' => 'edit_posts',
                                        'fields' => array('ID', 'display_name')
                                    ));
                                    foreach ($authors as $author) {
                                        echo '<option value="' . esc_attr($author->ID) . '">' . esc_html($author->display_name) . '</option>';
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="cpt_status"><?php _e('Status', 'cpt-export'); ?></label>
                            </th>
                            <td>
                                <select name="cpt_status" id="cpt_status">
                                    <option value=""><?php _e('All statuses', 'cpt-export'); ?></option>
                                    <option value="publish"><?php _e('Published', 'cpt-export'); ?></option>
                                    <option value="draft"><?php _e('Draft', 'cpt-export'); ?></option>
                                    <option value="private"><?php _e('Private', 'cpt-export'); ?></option>
                                    <option value="pending"><?php _e('Pending Review', 'cpt-export'); ?></option>
                                    <option value="future"><?php _e('Scheduled', 'cpt-export'); ?></option>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><?php _e('Date Range', 'cpt-export'); ?></th>
                            <td>
                                <fieldset>
                                    <legend class="screen-reader-text"><?php _e('Date Range', 'cpt-export'); ?></legend>
                                    <label for="cpt_start_date">
                                        <?php _e('Start Date:', 'cpt-export'); ?>
                                        <input type="date" name="cpt_start_date" id="cpt_start_date">
                                    </label>
                                    <br><br>
                                    <label for="cpt_end_date">
                                        <?php _e('End Date:', 'cpt-export'); ?>
                                        <input type="date" name="cpt_end_date" id="cpt_end_date">
                                    </label>
                                    <p class="description"><?php _e('Leave blank to export all dates.', 'cpt-export'); ?></p>
                                </fieldset>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><?php _e('Action', 'cpt-export'); ?></th>
                            <td>
                                <fieldset>
                                    <legend class="screen-reader-text"><?php _e('Export Action', 'cpt-export'); ?></legend>
                                    <label for="cpt_export_and_delete">
                                        <input type="checkbox" name="cpt_export_and_delete" id="cpt_export_and_delete"
                                            value="1">
                                        <?php _e('Move to Trash', 'cpt-export'); ?>
                                    </label>
                                    <br><br>
                                    <label for="cpt_delete_permanently">
                                        <input type="checkbox" name="cpt_delete_permanently" id="cpt_delete_permanently"
                                            value="1">
                                        <?php _e('Delete Permanently (bypass trash)', 'cpt-export'); ?>
                                    </label>
                                    <br><br>
                                    <label for="cpt_delete_media">
                                        <input type="checkbox" name="cpt_delete_media" id="cpt_delete_media" value="1">
                                        <?php _e('Delete Media Permanently', 'cpt-export'); ?>
                                    </label>
                                    <p class="description" style="color: #d63638;">
                                        <strong><?php _e('Warning:', 'cpt-export'); ?></strong>
                                        <?php _e('Checking "Move to Trash" will move all exported posts to trash after export. If "Delete Permanently" is also checked, posts will bypass trash. If "Delete Media Permanently" is checked, attached media files will be permanently deleted (be careful if media is shared between posts). These actions cannot be undone!', 'cpt-export'); ?>
                                    </p>
                                </fieldset>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="cpt_save_folder"><?php _e('Save in Folder', 'cpt-export'); ?></label>
                            </th>
                            <td>
                                <input type="text" name="cpt_save_folder" id="cpt_save_folder" class="regular-text"
                                    placeholder="<?php esc_attr_e('Leave empty to download', 'cpt-export'); ?>">
                                <p class="description">
                                    <?php
                                    $uploads_dir = wp_upload_dir();
                                    printf(
                                        __('Optional: Enter folder name to save file in %s/[folder_name]/ instead of downloading. Leave empty to download the file.', 'cpt-export'),
                                        '<code>' . esc_html($uploads_dir['basedir']) . '</code>'
                                    );
                                    ?>
                                    <br>
                                    <?php _e('File will be named: digma-[post_type]-[start_date]-[end_date].xml', 'cpt-export'); ?>
                                </p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="cpt_compress"><?php _e('Compress File', 'cpt-export'); ?></label>
                            </th>
                            <td>
                                <label for="cpt_compress">
                                    <input type="checkbox" name="cpt_compress" id="cpt_compress" value="1">
                                    <?php _e('Compress export file (ZIP)', 'cpt-export'); ?>
                                </label>
                                <p class="description">
                                    <?php _e('Creates a ZIP file containing the XML export. Useful for large exports or email attachments.', 'cpt-export'); ?>
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>

                <p class="submit">
                    <input type="submit" name="submit" id="submit" class="button button-primary"
                        value="<?php esc_attr_e('Download Export File', 'cpt-export'); ?>">
                </p>
            </form>
        </div>

        <script>
            jQuery(document).ready(function ($) {
                $('#cpt-export-form').on('submit', function (e) {
                    var postType = $('#cpt_post_type').val();
                    var exportAndDelete = $('#cpt_export_and_delete').is(':checked');
                    var deletePermanently = $('#cpt_delete_permanently').is(':checked');
                    var deleteMedia = $('#cpt_delete_media').is(':checked');

                    if (!postType) {
                        e.preventDefault();
                        alert('<?php echo esc_js(__('Please select a post type to export.', 'cpt-export')); ?>');
                        return false;
                    }

                    if (exportAndDelete) {
                        var confirmMessage = '';

                        if (deletePermanently && deleteMedia) {
                            confirmMessage = '<?php echo esc_js(__('WARNING: You have chosen to export and permanently delete posts AND their media. This will permanently delete all exported posts, their metadata, and attached media files, bypassing the trash. Media shared with other posts will also be deleted. This action cannot be undone!\n\nAre you absolutely sure you want to continue?', 'cpt-export')); ?>';
                        } else if (deletePermanently) {
                            confirmMessage = '<?php echo esc_js(__('WARNING: You have chosen to export and permanently delete posts. This will permanently delete all exported posts and their metadata, bypassing the trash. Media files will be preserved. This action cannot be undone!\n\nAre you absolutely sure you want to continue?', 'cpt-export')); ?>';
                        } else if (deleteMedia) {
                            confirmMessage = '<?php echo esc_js(__('WARNING: You have chosen to export and move posts to trash with their media deleted. This will move posts to trash and permanently delete attached media files. Media shared with other posts will also be deleted. This action cannot be undone!\n\nAre you sure you want to continue?', 'cpt-export')); ?>';
                        } else {
                            confirmMessage = '<?php echo esc_js(__('WARNING: You have chosen to move posts to trash after export. This will move all exported posts to trash. Media files will be preserved.\n\nAre you sure you want to continue?', 'cpt-export')); ?>';
                        }

                        if (!confirm(confirmMessage)) {
                            e.preventDefault();
                            return false;
                        }
                    }
                });

                $('#cpt_export_and_delete').on('change', function () {
                    var isChecked = $(this).is(':checked');
                    var isPermanent = $('#cpt_delete_permanently').is(':checked');
                    var isDeleteMedia = $('#cpt_delete_media').is(':checked');

                    $('#cpt_delete_permanently').prop('disabled', !isChecked);
                    $('#cpt_delete_media').prop('disabled', !isChecked);

                    if (isChecked) {
                        $(this).closest('tr').find('.description').show();
                        $('#submit').removeClass('button-primary').addClass('button-secondary');
                        updateButtonText();
                    } else {
                        $('#submit').removeClass('button-secondary').addClass('button-primary');
                        $('#submit').val('<?php echo esc_js(__('Download Export File', 'cpt-export')); ?>');
                        $('#cpt_delete_permanently').prop('checked', false);
                        $('#cpt_delete_media').prop('checked', false);
                    }
                });

                $('#cpt_delete_permanently, #cpt_delete_media').on('change', function () {
                    if ($('#cpt_export_and_delete').is(':checked')) {
                        updateButtonText();
                    }
                });

                function updateButtonText() {
                    var isPermanent = $('#cpt_delete_permanently').is(':checked');
                    var isDeleteMedia = $('#cpt_delete_media').is(':checked');
                    var saveFolder = $('#cpt_save_folder').val().trim();
                    var buttonText = '';

                    var action = saveFolder ? '<?php echo esc_js(__('Save', 'cpt-export')); ?>' : '<?php echo esc_js(__('Download', 'cpt-export')); ?>';

                    if ($('#cpt_export_and_delete').is(':checked')) {
                        if (isPermanent && isDeleteMedia) {
                            buttonText = action + ' <?php echo esc_js(__('and Permanently Delete Posts + Media', 'cpt-export')); ?>';
                        } else if (isPermanent) {
                            buttonText = action + ' <?php echo esc_js(__('and Permanently Delete Posts', 'cpt-export')); ?>';
                        } else if (isDeleteMedia) {
                            buttonText = action + ' <?php echo esc_js(__('and Move Posts to Trash + Delete Media', 'cpt-export')); ?>';
                        } else {
                            buttonText = action + ' <?php echo esc_js(__('and Move Posts to Trash', 'cpt-export')); ?>';
                        }
                    } else {
                        buttonText = action + ' <?php echo esc_js(__('Export File', 'cpt-export')); ?>';
                    }

                    $('#submit').val(buttonText);
                }

                $('#cpt_save_folder').on('input', function () {
                    updateButtonText();
                });

                // Initialize state
                $('#cpt_delete_permanently').prop('disabled', !$('#cpt_export_and_delete').is(':checked'));
                $('#cpt_delete_media').prop('disabled', !$('#cpt_export_and_delete').is(':checked'));
            });
        </script>

        <style>
            #cpt_export_and_delete:checked+label,
            #cpt_delete_permanently:checked+label,
            #cpt_delete_media:checked+label {
                font-weight: bold;
                color: #d63638;
            }

            #cpt_delete_permanently:disabled+label,
            #cpt_delete_media:disabled+label {
                opacity: 0.5;
                color: #666;
            }
        </style>
        <?php
    }

    public function handle_export()
    {
        if (!isset($_POST['submit']) || !isset($_POST['cpt_export_nonce'])) {
            return;
        }

        if (!wp_verify_nonce($_POST['cpt_export_nonce'], 'cpt_export_nonce')) {
            wp_die(__('Security check failed', 'cpt-export'));
        }

        if (!current_user_can('export')) {
            wp_die(__('You do not have sufficient permissions to export content.', 'cpt-export'));
        }

        $post_type = sanitize_text_field($_POST['cpt_post_type']);
        $author = sanitize_text_field($_POST['cpt_author']);
        $status = sanitize_text_field($_POST['cpt_status']);
        $start_date = sanitize_text_field($_POST['cpt_start_date']);
        $end_date = sanitize_text_field($_POST['cpt_end_date']);
        $export_and_delete = isset($_POST['cpt_export_and_delete']) && $_POST['cpt_export_and_delete'] === '1';
        $delete_permanently = isset($_POST['cpt_delete_permanently']) && $_POST['cpt_delete_permanently'] === '1';
        $delete_media = isset($_POST['cpt_delete_media']) && $_POST['cpt_delete_media'] === '1';
        $save_folder = sanitize_text_field($_POST['cpt_save_folder']);
        $compress = isset($_POST['cpt_compress']) && $_POST['cpt_compress'] === '1';

        if (empty($post_type)) {
            wp_die(__('Please select a post type to export.', 'cpt-export'));
        }

        // Additional permission check for delete functionality
        if ($export_and_delete && !current_user_can('delete_posts')) {
            wp_die(__('You do not have sufficient permissions to delete content.', 'cpt-export'));
        }

        $this->export_cpt($post_type, $author, $status, $start_date, $end_date, $export_and_delete, $delete_permanently, $delete_media, $save_folder, $compress);
    }

    public function export_cpt($post_type, $author = '', $status = '', $start_date = '', $end_date = '', $export_and_delete = false, $delete_permanently = false, $delete_media = false, $save_folder = '', $compress = false)
    {
        // Build query arguments
        $args = array(
            'post_type' => $post_type,
            'posts_per_page' => -1,
            'post_status' => $status ? $status : array('publish', 'draft', 'private', 'pending', 'future'),
            'orderby' => 'date',
            'order' => 'DESC'
        );

        if (!empty($author)) {
            $args['author'] = $author;
        }

        // Add date query if dates are provided
        if (!empty($start_date) || !empty($end_date)) {
            $date_query = array();

            if (!empty($start_date)) {
                $date_query['after'] = array(
                    'year' => date('Y', strtotime($start_date)),
                    'month' => date('m', strtotime($start_date)),
                    'day' => date('d', strtotime($start_date)),
                    'inclusive' => true
                );
            }

            if (!empty($end_date)) {
                // Make end date inclusive by adding 23:59:59 to the date
                $end_date_inclusive = date('Y-m-d', strtotime($end_date . ' +1 day'));
                $date_query['before'] = array(
                    'year' => date('Y', strtotime($end_date_inclusive)),
                    'month' => date('m', strtotime($end_date_inclusive)),
                    'day' => date('d', strtotime($end_date_inclusive)),
                    'inclusive' => false
                );
            }

            $args['date_query'] = array($date_query);
        }

        $posts = get_posts($args);

        if (empty($posts)) {
            wp_die(__('No posts found matching your criteria.', 'cpt-export'));
        }

        // Collect all attachment IDs for media export
        $attachment_ids = array();
        foreach ($posts as $post) {
            // Get featured image
            $featured_image_id = get_post_thumbnail_id($post->ID);
            if ($featured_image_id) {
                $attachment_ids[] = $featured_image_id;
            }

            // Get attachments from post content
            $content_attachments = $this->get_content_attachments($post->post_content);
            $attachment_ids = array_merge($attachment_ids, $content_attachments);

            // Get attachments uploaded to this post
            $post_attachments = get_attached_media('', $post->ID);
            foreach ($post_attachments as $attachment) {
                $attachment_ids[] = $attachment->ID;
            }
        }

        // Remove duplicates
        $attachment_ids = array_unique($attachment_ids);

        // Get attachment posts
        $attachments = array();
        if (!empty($attachment_ids)) {
            $attachments = get_posts(array(
                'post_type' => 'attachment',
                'post__in' => $attachment_ids,
                'posts_per_page' => -1,
                'post_status' => 'inherit'
            ));
        }

        // Generate filename with new format
        $filename = $this->generate_filename($post_type, $start_date, $end_date, $compress);

        // Generate XML
        $xml = $this->generate_xml($posts, $attachments, $post_type);

        // Handle compression if requested
        if ($compress) {
            $file_data = $this->create_zip_file($xml, $filename);
            $content_type = 'application/zip';
        } else {
            $file_data = $xml;
            $content_type = 'text/xml; charset=' . get_option('blog_charset');
        }

        // Handle save to folder or download
        if (!empty($save_folder)) {
            // Save to uploads folder
            $file_path = $this->save_to_uploads_folder($file_data, $filename, $save_folder, $compress);

            if ($file_path) {
                // If export and delete is enabled, delete the posts and media
                if ($export_and_delete) {
                    $this->delete_posts_and_media($posts, $attachments, $delete_permanently, $delete_media);
                }

                // Redirect back to admin page with success message
                $redirect_url = add_query_arg(array(
                    'page' => 'cpt-export-tool',
                    'saved' => '1',
                    'file_path' => urlencode($file_path),
                    'count' => count($posts),
                    'compressed' => $compress ? '1' : '0'
                ), admin_url('tools.php'));

                wp_redirect($redirect_url);
                exit;
            } else {
                wp_die(__('Error: Could not save file to the specified folder.', 'cpt-export'));
            }
        } else {
            // Download file
            header('Content-Description: File Transfer');
            header('Content-Disposition: attachment; filename=' . $filename);
            header('Content-Type: ' . $content_type);

            echo $file_data;

            // If export and delete is enabled, delete the posts and media
            if ($export_and_delete) {
                $this->delete_posts_and_media($posts, $attachments, $delete_permanently, $delete_media);
            }

            exit;
        }
    }

    private function get_content_attachments($content)
    {
        $attachment_ids = array();

        // Find WordPress image classes and extract attachment IDs
        if (preg_match_all('/wp-image-(\d+)/', $content, $matches)) {
            $attachment_ids = array_merge($attachment_ids, $matches[1]);
        }

        // Find gallery shortcodes and extract IDs
        if (preg_match_all('/\[gallery[^\]]*ids=["\']([^"\']+)["\']/', $content, $matches)) {
            foreach ($matches[1] as $ids_string) {
                $ids = explode(',', $ids_string);
                $attachment_ids = array_merge($attachment_ids, array_map('trim', $ids));
            }
        }

        // Find attachment URLs and convert to IDs
        if (preg_match_all('/wp-content\/uploads\/[^"\'\s]+\.(jpg|jpeg|png|gif|webp|pdf|doc|docx)/i', $content, $matches)) {
            foreach ($matches[0] as $url) {
                $attachment_id = attachment_url_to_postid($url);
                if ($attachment_id) {
                    $attachment_ids[] = $attachment_id;
                }
            }
        }

        return array_map('intval', array_filter($attachment_ids));
    }

    private function generate_filename($post_type, $start_date = '', $end_date = '', $compress = false)
    {
        $filename = 'digma-' . sanitize_file_name($post_type);

        // Add start date if provided
        if (!empty($start_date)) {
            $filename .= '-' . sanitize_file_name($start_date);
        } else {
            $filename .= '-all';
        }

        // Add end date if provided
        if (!empty($end_date)) {
            $filename .= '-' . sanitize_file_name($end_date);
        } else {
            $filename .= '-' . date('Y-m-d');
        }

        // Add appropriate extension
        $extension = $compress ? '.zip' : '.xml';
        return $filename . $extension;
    }

    private function create_zip_file($xml_content, $filename)
    {
        // Check if ZipArchive is available
        if (!class_exists('ZipArchive')) {
            wp_die(__('Error: ZIP compression is not available on this server. ZipArchive extension is required.', 'cpt-export'));
        }

        // Create temporary file for ZIP with proper extension
        $temp_zip = tempnam(sys_get_temp_dir(), 'cpt_export_') . '.zip';

        $zip = new ZipArchive();
        $result = $zip->open($temp_zip, ZipArchive::CREATE | ZipArchive::OVERWRITE);

        if ($result !== TRUE) {
            wp_die(sprintf(__('Error: Could not create ZIP file. Error code: %d', 'cpt-export'), $result));
        }

        // Add XML content to ZIP with original filename (but .xml extension)
        $xml_filename = str_replace('.zip', '.xml', $filename);
        $zip->addFromString($xml_filename, $xml_content);
        $zip->close();

        // Read ZIP file content
        $zip_content = file_get_contents($temp_zip);

        // Clean up temporary file
        unlink($temp_zip);

        if ($zip_content === false) {
            wp_die(__('Error: Could not read ZIP file content.', 'cpt-export'));
        }

        return $zip_content;
    }

    private function save_to_uploads_folder($file_content, $filename, $folder_name, $compress = false)
    {
        // Get uploads directory
        $uploads_dir = wp_upload_dir();

        if ($uploads_dir['error']) {
            return false;
        }

        // Sanitize folder name
        $folder_name = sanitize_file_name($folder_name);

        // Create target directory path
        $target_dir = $uploads_dir['basedir'] . '/' . $folder_name;

        // Create directory if it doesn't exist
        if (!wp_mkdir_p($target_dir)) {
            return false;
        }

        // Full file path
        $file_path = $target_dir . '/' . $filename;

        // Save file (binary mode for ZIP files)
        $result = file_put_contents($file_path, $file_content, LOCK_EX);

        if ($result === false) {
            return false;
        }

        // Return relative path from uploads directory
        return $folder_name . '/' . $filename;
    }

    private function delete_posts_and_media($posts, $attachments, $delete_permanently = false, $delete_media = false)
    {
        // Delete attachments only if delete_media is enabled
        if ($delete_media) {
            foreach ($attachments as $attachment) {
                // Delete all metadata
                $meta_keys = get_post_custom_keys($attachment->ID);
                if ($meta_keys) {
                    foreach ($meta_keys as $meta_key) {
                        delete_post_meta($attachment->ID, $meta_key);
                    }
                }

                // Delete physical files permanently
                wp_delete_attachment($attachment->ID, true);
            }
        }

        // Delete posts
        foreach ($posts as $post) {
            if ($delete_permanently) {
                // Only clean up metadata/relationships if permanently deleting

                // Delete all post metadata
                $meta_keys = get_post_custom_keys($post->ID);
                if ($meta_keys) {
                    foreach ($meta_keys as $meta_key) {
                        delete_post_meta($post->ID, $meta_key);
                    }
                }

                // Delete taxonomy relationships
                $taxonomies = get_object_taxonomies($post->post_type);
                foreach ($taxonomies as $taxonomy) {
                    wp_delete_object_term_relationships($post->ID, $taxonomy);
                }

                // Delete comments and their metadata
                $comments = get_comments(array('post_id' => $post->ID));
                foreach ($comments as $comment) {
                    wp_delete_comment($comment->comment_ID, true);
                }

                // Permanently delete the post
                wp_delete_post($post->ID, true);
            } else {
                // Move to trash - WordPress will handle everything properly
                wp_trash_post($post->ID);
            }
        }
    }

    public function generate_xml($posts, $attachments, $post_type)
    {
        $sitename = sanitize_key(get_bloginfo('name'));
        if (!empty($sitename)) {
            $sitename .= '.';
        }

        $xml = '<?xml version="1.0" encoding="' . get_bloginfo('charset') . "\" ?>\n";
        $xml .= "<!-- This is a WordPress eXtended RSS file generated by CPT Export as an export of your site. -->\n";
        $xml .= "<!-- It contains information about your site's posts, pages, comments, categories, and other content. -->\n";
        $xml .= "<!-- You may use this file to transfer that content from one site to another. -->\n";
        $xml .= "<!-- This file is not intended to serve as a complete backup of your site. -->\n\n";

        $xml .= '<rss version="2.0"' . "\n";
        $xml .= "\t" . 'xmlns:excerpt="http://wordpress.org/export/1.2/excerpt/"' . "\n";
        $xml .= "\t" . 'xmlns:content="http://purl.org/rss/1.0/modules/content/"' . "\n";
        $xml .= "\t" . 'xmlns:wfw="http://wellformedweb.org/CommentAPI/"' . "\n";
        $xml .= "\t" . 'xmlns:dc="http://purl.org/dc/elements/1.1/"' . "\n";
        $xml .= "\t" . 'xmlns:wp="http://wordpress.org/export/1.2/"' . "\n";
        $xml .= ">\n\n";

        $xml .= "<channel>\n";
        $xml .= "\t<title>" . esc_html(get_bloginfo('name')) . "</title>\n";
        $xml .= "\t<link>" . esc_url(get_bloginfo('url')) . "</link>\n";
        $xml .= "\t<description>" . esc_html(get_bloginfo('description')) . "</description>\n";
        $xml .= "\t<pubDate>" . date('D, d M Y H:i:s +0000') . "</pubDate>\n";
        $xml .= "\t<language>" . esc_html(get_bloginfo('language')) . "</language>\n";
        $xml .= "\t<wp:wxr_version>1.2</wp:wxr_version>\n";
        $xml .= "\t<wp:base_site_url>" . esc_url(get_option('home')) . "</wp:base_site_url>\n";
        $xml .= "\t<wp:base_blog_url>" . esc_url(get_bloginfo('url')) . "</wp:base_blog_url>\n\n";

        // Export attachments first
        foreach ($attachments as $attachment) {
            $xml .= $this->generate_post_xml($attachment);
        }

        // Export posts
        foreach ($posts as $post) {
            $xml .= $this->generate_post_xml($post);
        }

        $xml .= "</channel>\n";
        $xml .= "</rss>\n";

        return $xml;
    }

    public function generate_post_xml($post)
    {
        $xml = "\t<item>\n";
        $xml .= "\t\t<title>" . $this->wxr_cdata($post->post_title) . "</title>\n";
        $xml .= "\t\t<link>" . esc_url(get_permalink($post)) . "</link>\n";
        $xml .= "\t\t<pubDate>" . mysql2date('D, d M Y H:i:s +0000', $post->post_date, false) . "</pubDate>\n";
        $xml .= "\t\t<dc:creator>" . $this->wxr_cdata(get_the_author_meta('login', $post->post_author)) . "</dc:creator>\n";
        $xml .= "\t\t<guid isPermaLink=\"false\">" . esc_url(get_the_guid($post->ID)) . "</guid>\n";
        $xml .= "\t\t<description></description>\n";
        $xml .= "\t\t<content:encoded>" . $this->wxr_cdata($post->post_content) . "</content:encoded>\n";
        $xml .= "\t\t<excerpt:encoded>" . $this->wxr_cdata($post->post_excerpt) . "</excerpt:encoded>\n";
        $xml .= "\t\t<wp:post_id>" . intval($post->ID) . "</wp:post_id>\n";
        $xml .= "\t\t<wp:post_date>" . $this->wxr_cdata($post->post_date) . "</wp:post_date>\n";
        $xml .= "\t\t<wp:post_date_gmt>" . $this->wxr_cdata($post->post_date_gmt) . "</wp:post_date_gmt>\n";
        $xml .= "\t\t<wp:comment_status>" . $this->wxr_cdata($post->comment_status) . "</wp:comment_status>\n";
        $xml .= "\t\t<wp:ping_status>" . $this->wxr_cdata($post->ping_status) . "</wp:ping_status>\n";
        $xml .= "\t\t<wp:post_name>" . $this->wxr_cdata($post->post_name) . "</wp:post_name>\n";
        $xml .= "\t\t<wp:status>" . $this->wxr_cdata($post->post_status) . "</wp:status>\n";
        $xml .= "\t\t<wp:post_parent>" . intval($post->post_parent) . "</wp:post_parent>\n";
        $xml .= "\t\t<wp:menu_order>" . intval($post->menu_order) . "</wp:menu_order>\n";
        $xml .= "\t\t<wp:post_type>" . $this->wxr_cdata($post->post_type) . "</wp:post_type>\n";
        $xml .= "\t\t<wp:post_password>" . $this->wxr_cdata($post->post_password) . "</wp:post_password>\n";
        $xml .= "\t\t<wp:is_sticky>" . intval($post->post_type == 'post' && is_sticky($post->ID)) . "</wp:is_sticky>\n";

        // For attachments, add the attachment URL
        if ($post->post_type === 'attachment') {
            $xml .= "\t\t<wp:attachment_url>" . $this->wxr_cdata(wp_get_attachment_url($post->ID)) . "</wp:attachment_url>\n";
        }

        // Export all metadata (including private fields for complete export)
        $custom_fields = get_post_custom($post->ID);
        if (!empty($custom_fields)) {
            foreach ($custom_fields as $key => $values) {
                foreach ($values as $value) {
                    $xml .= "\t\t<wp:postmeta>\n";
                    $xml .= "\t\t\t<wp:meta_key>" . $this->wxr_cdata($key) . "</wp:meta_key>\n";
                    $xml .= "\t\t\t<wp:meta_value>" . $this->wxr_cdata($value) . "</wp:meta_value>\n";
                    $xml .= "\t\t</wp:postmeta>\n";
                }
            }
        }

        // Export taxonomies
        $taxonomies = get_object_taxonomies($post->post_type);
        if (!empty($taxonomies)) {
            foreach ($taxonomies as $taxonomy) {
                $terms = get_the_terms($post->ID, $taxonomy);
                if (!empty($terms) && !is_wp_error($terms)) {
                    foreach ($terms as $term) {
                        $xml .= "\t\t<category domain=\"" . esc_attr($taxonomy) . "\" nicename=\"" . esc_attr($term->slug) . "\">" . $this->wxr_cdata($term->name) . "</category>\n";
                    }
                }
            }
        }

        // Export comments
        $comments = get_comments(array('post_id' => $post->ID, 'order' => 'ASC'));
        foreach ($comments as $comment) {
            $xml .= "\t\t<wp:comment>\n";
            $xml .= "\t\t\t<wp:comment_id>" . intval($comment->comment_ID) . "</wp:comment_id>\n";
            $xml .= "\t\t\t<wp:comment_author>" . $this->wxr_cdata($comment->comment_author) . "</wp:comment_author>\n";
            $xml .= "\t\t\t<wp:comment_author_email>" . $this->wxr_cdata($comment->comment_author_email) . "</wp:comment_author_email>\n";
            $xml .= "\t\t\t<wp:comment_author_url>" . esc_url($comment->comment_author_url) . "</wp:comment_author_url>\n";
            $xml .= "\t\t\t<wp:comment_author_IP>" . $this->wxr_cdata($comment->comment_author_IP) . "</wp:comment_author_IP>\n";
            $xml .= "\t\t\t<wp:comment_date>" . $this->wxr_cdata($comment->comment_date) . "</wp:comment_date>\n";
            $xml .= "\t\t\t<wp:comment_date_gmt>" . $this->wxr_cdata($comment->comment_date_gmt) . "</wp:comment_date_gmt>\n";
            $xml .= "\t\t\t<wp:comment_content>" . $this->wxr_cdata($comment->comment_content) . "</wp:comment_content>\n";
            $xml .= "\t\t\t<wp:comment_approved>" . $this->wxr_cdata($comment->comment_approved) . "</wp:comment_approved>\n";
            $xml .= "\t\t\t<wp:comment_type>" . $this->wxr_cdata($comment->comment_type) . "</wp:comment_type>\n";
            $xml .= "\t\t\t<wp:comment_parent>" . intval($comment->comment_parent) . "</wp:comment_parent>\n";
            $xml .= "\t\t\t<wp:comment_user_id>" . intval($comment->user_id) . "</wp:comment_user_id>\n";

            // Export comment metadata
            $comment_meta = get_comment_meta($comment->comment_ID);
            if (!empty($comment_meta)) {
                foreach ($comment_meta as $key => $values) {
                    foreach ($values as $value) {
                        $xml .= "\t\t\t<wp:commentmeta>\n";
                        $xml .= "\t\t\t\t<wp:meta_key>" . $this->wxr_cdata($key) . "</wp:meta_key>\n";
                        $xml .= "\t\t\t\t<wp:meta_value>" . $this->wxr_cdata($value) . "</wp:meta_value>\n";
                        $xml .= "\t\t\t</wp:commentmeta>\n";
                    }
                }
            }

            $xml .= "\t\t</wp:comment>\n";
        }

        $xml .= "\t</item>\n\n";

        return $xml;
    }

    private function wxr_cdata($str)
    {
        // Ensure UTF-8 encoding for modern PHP compatibility
        if (!mb_check_encoding($str, 'UTF-8')) {
            $str = mb_convert_encoding($str, 'UTF-8', mb_detect_encoding($str));
        }

        $str = '<![CDATA[' . str_replace(']]>', ']]]]><![CDATA[>', $str) . ']]>';

        return $str;
    }

    /**
     * Shortcode handler for CPT export
     * Usage: [cpt_export post_type="product" author="1" status="publish" start_date="2024-01-01" end_date="2024-12-31" delete="1" permanent="1" download="1"]
     */
    public function shortcode_handler($atts)
    {
        // Only allow shortcode execution for users with export capability
        if (!current_user_can('export')) {
            return '<p style="color: red;">' . __('You do not have permission to use this shortcode.', 'cpt-export') . '</p>';
        }

        $atts = shortcode_atts(array(
            'post_type' => '',
            'author' => '',
            'status' => '',
            'start_date' => '',
            'end_date' => '',
            'delete' => '0',
            'permanent' => '0',
            'delete_media' => '0',
            'save_folder' => '',
            'compress' => '0',
            'download' => '1',
            'return_data' => '0'
        ), $atts, 'cpt_export');

        // Validate required parameters
        if (empty($atts['post_type'])) {
            return '<p style="color: red;">' . __('Error: post_type parameter is required.', 'cpt-export') . '</p>';
        }

        // Validate post type exists
        if (!post_type_exists($atts['post_type'])) {
            return '<p style="color: red;">' . sprintf(__('Error: Post type "%s" does not exist.', 'cpt-export'), esc_html($atts['post_type'])) . '</p>';
        }

        // Additional permission check for delete functionality
        $export_and_delete = ($atts['delete'] === '1');
        $delete_permanently = ($atts['permanent'] === '1');
        $delete_media = ($atts['delete_media'] === '1');
        $compress = ($atts['compress'] === '1');

        if ($export_and_delete && !current_user_can('delete_posts')) {
            return '<p style="color: red;">' . __('You do not have permission to delete posts.', 'cpt-export') . '</p>';
        }

        try {
            // Build query arguments
            $args = array(
                'post_type' => sanitize_text_field($atts['post_type']),
                'posts_per_page' => -1,
                'post_status' => !empty($atts['status']) ? sanitize_text_field($atts['status']) : array('publish', 'draft', 'private', 'pending', 'future'),
                'orderby' => 'date',
                'order' => 'DESC'
            );

            if (!empty($atts['author'])) {
                $args['author'] = intval($atts['author']);
            }

            // Add date query if dates are provided
            if (!empty($atts['start_date']) || !empty($atts['end_date'])) {
                $date_query = array();

                if (!empty($atts['start_date'])) {
                    $start_date = sanitize_text_field($atts['start_date']);
                    $date_query['after'] = array(
                        'year' => date('Y', strtotime($start_date)),
                        'month' => date('m', strtotime($start_date)),
                        'day' => date('d', strtotime($start_date)),
                        'inclusive' => true
                    );
                }

                if (!empty($atts['end_date'])) {
                    $end_date = sanitize_text_field($atts['end_date']);
                    // Make end date inclusive by adding 1 day and setting inclusive to false
                    $end_date_inclusive = date('Y-m-d', strtotime($end_date . ' +1 day'));
                    $date_query['before'] = array(
                        'year' => date('Y', strtotime($end_date_inclusive)),
                        'month' => date('m', strtotime($end_date_inclusive)),
                        'day' => date('d', strtotime($end_date_inclusive)),
                        'inclusive' => false
                    );
                }

                $args['date_query'] = array($date_query);
            }

            $posts = get_posts($args);

            if (empty($posts)) {
                return '<p style="color: orange;">' . __('No posts found matching your criteria.', 'cpt-export') . '</p>';
            }

            // Collect attachments
            $attachment_ids = array();
            foreach ($posts as $post) {
                // Get featured image
                $featured_image_id = get_post_thumbnail_id($post->ID);
                if ($featured_image_id) {
                    $attachment_ids[] = $featured_image_id;
                }

                // Get attachments from post content
                $content_attachments = $this->get_content_attachments($post->post_content);
                $attachment_ids = array_merge($attachment_ids, $content_attachments);

                // Get attachments uploaded to this post
                $post_attachments = get_attached_media('', $post->ID);
                foreach ($post_attachments as $attachment) {
                    $attachment_ids[] = $attachment->ID;
                }
            }

            // Remove duplicates
            $attachment_ids = array_unique($attachment_ids);

            // Get attachment posts
            $attachments = array();
            if (!empty($attachment_ids)) {
                $attachments = get_posts(array(
                    'post_type' => 'attachment',
                    'post__in' => $attachment_ids,
                    'posts_per_page' => -1,
                    'post_status' => 'inherit'
                ));
            }

            // Generate XML
            $xml = $this->generate_xml($posts, $attachments, $atts['post_type']);

            // Generate filename
            $filename = $this->generate_filename($atts['post_type'], $atts['start_date'], $atts['end_date'], $compress);

            // Handle compression if requested
            if ($compress) {
                $file_data = $this->create_zip_file($xml, $filename);
                $content_type = 'application/zip';
            } else {
                $file_data = $xml;
                $content_type = 'text/xml; charset=' . get_option('blog_charset');
            }

            // Handle save to folder or download
            if (!empty($atts['save_folder'])) {
                // Save to uploads folder
                $file_path = $this->save_to_uploads_folder($file_data, $filename, $atts['save_folder'], $compress);

                if ($file_path) {
                    // If export and delete is enabled, delete the posts and media
                    if ($export_and_delete) {
                        $this->delete_posts_and_media($posts, $attachments, $delete_permanently, $delete_media);
                    }

                    $uploads_dir = wp_upload_dir();
                    $full_url = $uploads_dir['baseurl'] . '/' . $file_path;
                    $file_type = $compress ? 'ZIP' : 'XML';

                    return '<p style="color: green;">' .
                        sprintf(
                            __('Successfully saved %s export to: %s', 'cpt-export'),
                            $file_type,
                            '<br><a href="' . esc_url($full_url) . '" target="_blank">' . esc_html($file_path) . '</a>'
                        ) .
                        '</p>';
                } else {
                    return '<p style="color: red;">' . __('Error: Could not save file to the specified folder.', 'cpt-export') . '</p>';
                }
            }

            // Handle download
            if ($atts['download'] === '1') {
                header('Content-Description: File Transfer');
                header('Content-Disposition: attachment; filename=' . $filename);
                header('Content-Type: ' . $content_type);

                echo $file_data;

                // If export and delete is enabled, delete the posts and media
                if ($export_and_delete) {
                    $this->delete_posts_and_media($posts, $attachments, $delete_permanently, $delete_media);
                }

                exit;
            }

            // If return_data is enabled, return the XML content
            if ($atts['return_data'] === '1') {
                // If export and delete is enabled, delete the posts and media
                if ($export_and_delete) {
                    $this->delete_posts_and_media($posts, $attachments, $delete_permanently, $delete_media);
                }

                return '<pre>' . esc_html($xml) . '</pre>';
            }

            // Default: Return success message
            $post_count = count($posts);
            $attachment_count = count($attachments);

            // If export and delete is enabled, delete the posts and media
            if ($export_and_delete) {
                $this->delete_posts_and_media($posts, $attachments, $delete_permanently, $delete_media);

                $delete_message = $delete_permanently ?
                    __('and permanently deleted', 'cpt-export') :
                    __('and moved to trash', 'cpt-export');

                $media_message = $delete_media ?
                    __('Media was permanently deleted.', 'cpt-export') :
                    __('Media was preserved.', 'cpt-export');

                return '<p style="color: green;">' .
                    sprintf(
                        __('Successfully exported %1$d posts and %2$d attachments %3$s. %4$s', 'cpt-export'),
                        $post_count,
                        $attachment_count,
                        $delete_message,
                        $media_message
                    ) .
                    '</p>';
            } else {
                return '<p style="color: green;">' .
                    sprintf(
                        __('Successfully exported %1$d posts and %2$d attachments.', 'cpt-export'),
                        $post_count,
                        $attachment_count
                    ) .
                    '</p>';
            }

        } catch (Exception $e) {
            return '<p style="color: red;">' .
                sprintf(__('Error during export: %s', 'cpt-export'), esc_html($e->getMessage())) .
                '</p>';

        }
    }
}

// Initialize the plugin
new CPT_Export_Tool();

/**
 * Generate translation files
 * This creates the necessary translation files for the plugin
 */
function cpt_export_create_translation_files()
{
    $plugin_dir = plugin_dir_path(__FILE__);
    $languages_dir = $plugin_dir . 'languages/';

    // Create languages directory if it doesn't exist
    if (!file_exists($languages_dir)) {
        wp_mkdir_p($languages_dir);
    }

    // Create .pot file content
    $pot_content = '# Copyright (C) ' . date('Y') . ' CPT Export
# This file is distributed under the same license as the CPT Export package.
msgid ""
msgstr ""
"Project-Id-Version: CPT Export 1.0.86\\n"
"Report-Msgid-Bugs-To: https://site2goal.co.il\\n"
"POT-Creation-Date: ' . date('Y-m-d H:i:s') . '+0000\\n"
"MIME-Version: 1.0\\n"
"Content-Type: text/plain; charset=UTF-8\\n"
"Content-Transfer-Encoding: 8bit\\n"
"Language-Team: \\n"

msgid "CPT Export Tool"
msgstr ""

msgid "CPT Export"
msgstr ""

msgid "Export Custom Post Types"
msgstr ""

msgid "When you click the button below WordPress will create an XML file for you to save to your computer."
msgstr ""

msgid "This format, which is called WordPress eXtended RSS or WXR, will contain your posts, custom fields, categories, and other content."
msgstr ""

msgid "Choose what to export"
msgstr ""

msgid "Post Type"
msgstr ""

msgid "Select a post type..."
msgstr ""

msgid "Select the post type you want to export."
msgstr ""

msgid "Author"
msgstr ""

msgid "All authors"
msgstr ""

msgid "Status"
msgstr ""

msgid "All statuses"
msgstr ""

msgid "Published"
msgstr ""

msgid "Draft"
msgstr ""

msgid "Private"
msgstr ""

msgid "Pending Review"
msgstr ""

msgid "Scheduled"
msgstr ""

msgid "Date Range"
msgstr ""

msgid "Start Date:"
msgstr ""

msgid "End Date:"
msgstr ""

msgid "Leave blank to export all dates."
msgstr ""

msgid "Action"
msgstr ""

msgid "Export Action"
msgstr ""

msgid "Move to Trash"
msgstr ""

msgid "Delete Permanently (bypass trash)"
msgstr ""

msgid "Delete Media Permanently"
msgstr ""

msgid "Warning:"
msgstr ""

msgid "Checking \"Move to Trash\" will move all exported posts to trash after export. If \"Delete Permanently\" is also checked, posts will bypass trash. If \"Delete Media Permanently\" is checked, attached media files will be permanently deleted (be careful if media is shared between posts). These actions cannot be undone!"
msgstr ""

msgid "Save in Folder"
msgstr ""

msgid "Leave empty to download"
msgstr ""

msgid "Optional: Enter folder name to save file in %s/[folder_name]/ instead of downloading. Leave empty to download the file."
msgstr ""

msgid "File will be named: digma-[post_type]-[start_date]-[end_date].xml"
msgstr ""

msgid "Compress File"
msgstr ""

msgid "Compress export file (ZIP)"
msgstr ""

msgid "Creates a ZIP file containing the XML export. Useful for large exports or email attachments."
msgstr ""

msgid "Download Export File"
msgstr ""

msgid "Export Successful!"
msgstr ""

msgid "Successfully exported %d posts."
msgstr ""

msgid "Compressed file saved to: %s"
msgstr ""

msgid "File saved to: %s"
msgstr ""

msgid "Download File"
msgstr ""

msgid "Please select a post type to export."
msgstr ""

msgid "Security check failed"
msgstr ""

msgid "You do not have sufficient permissions to export content."
msgstr ""

msgid "You do not have sufficient permissions to delete content."
msgstr ""

msgid "No posts found matching your criteria."
msgstr ""

msgid "Error: Could not save file to the specified folder."
msgstr ""

msgid "Error: ZIP compression is not available on this server. ZipArchive extension is required."
msgstr ""

msgid "Error: Could not create ZIP file. Error code: %d"
msgstr ""

msgid "Error: Could not read ZIP file content."
msgstr ""
';

    // Create Hebrew translation content
    $he_content = '# Hebrew translation for CPT Export
# Copyright (C) ' . date('Y') . ' CPT Export
# This file is distributed under the same license as the CPT Export package.
msgid ""
msgstr ""
"Project-Id-Version: CPT Export 1.0.86\\n"
"Report-Msgid-Bugs-To: https://site2goal.co.il\\n"
"POT-Creation-Date: ' . date('Y-m-d H:i:s') . '+0000\\n"
"PO-Revision-Date: ' . date('Y-m-d H:i:s') . '+0000\\n"
"Last-Translator: \\n"
"Language-Team: Hebrew\\n"
"Language: he_IL\\n"
"MIME-Version: 1.0\\n"
"Content-Type: text/plain; charset=UTF-8\\n"
"Content-Transfer-Encoding: 8bit\\n"
"Plural-Forms: nplurals=2; plural=(n != 1);\\n"
"X-Generator: Manual\\n"

msgid "CPT Export Tool"
msgstr "כלי ייצוא סוגי פוסט מותאמים"

msgid "CPT Export"
msgstr "ייצוא CPT"

msgid "Export Custom Post Types"
msgstr "ייצוא סוגי פוסט מותאמים"

msgid "When you click the button below WordPress will create an XML file for you to save to your computer."
msgstr "כשתלחץ על הכפתור למטה, וורדפרס ייצור עבורך קובץ XML לשמירה במחשב."

msgid "This format, which is called WordPress eXtended RSS or WXR, will contain your posts, custom fields, categories, and other content."
msgstr "פורמט זה, הנקרא WordPress eXtended RSS או WXR, יכיל את הפוסטים, השדות המותאמים, הקטגוריות ותוכן נוסף."

msgid "Choose what to export"
msgstr "בחר מה לייצא"

msgid "Post Type"
msgstr "סוג פוסט"

msgid "Select a post type..."
msgstr "בחר סוג פוסט..."

msgid "Select the post type you want to export."
msgstr "בחר את סוג הפוסט שברצונך לייצא."

msgid "Author"
msgstr "מחבר"

msgid "All authors"
msgstr "כל המחברים"

msgid "Status"
msgstr "סטטוס"

msgid "All statuses"
msgstr "כל הסטטוסים"

msgid "Published"
msgstr "פורסם"

msgid "Draft"
msgstr "טיוטה"

msgid "Private"
msgstr "פרטי"

msgid "Pending Review"
msgstr "ממתין לאישור"

msgid "Scheduled"
msgstr "מתוזמן"

msgid "Date Range"
msgstr "טווח תאריכים"

msgid "Start Date:"
msgstr "תאריך התחלה:"

msgid "End Date:"
msgstr "תאריך סיום:"

msgid "Leave blank to export all dates."
msgstr "השאר ריק לייצוא כל התאריכים."

msgid "Action"
msgstr "פעולה"

msgid "Export Action"
msgstr "פעולת ייצוא"

msgid "Move to Trash"
msgstr "העבר לפח"

msgid "Delete Permanently (bypass trash)"
msgstr "מחק לצמיתות (עקוף פח)"

msgid "Delete Media Permanently"
msgstr "מחק מדיה לצמיתות"

msgid "Warning:"
msgstr "אזהרה:"

msgid "Checking \"Move to Trash\" will move all exported posts to trash after export. If \"Delete Permanently\" is also checked, posts will bypass trash. If \"Delete Media Permanently\" is checked, attached media files will be permanently deleted (be careful if media is shared between posts). These actions cannot be undone!"
msgstr "סימון \"העבר לפח\" יעביר את כל הפוסטים המיוצאים לפח לאחר הייצוא. אם \"מחק לצמיתות\" מסומן גם כן, הפוסטים יעקפו את הפח. אם \"מחק מדיה לצמיתות\" מסומן, קבצי המדיה המצורפים יימחקו לצמיתות (היזהר אם המדיה משותפת בין פוסטים). פעולות אלה אינן ניתנות לביטול!"

msgid "Save in Folder"
msgstr "שמור בתיקייה"

msgid "Leave empty to download"
msgstr "השאר ריק להורדה"

msgid "Optional: Enter folder name to save file in %s/[folder_name]/ instead of downloading. Leave empty to download the file."
msgstr "אופציונלי: הזן שם תיקייה לשמירת הקובץ ב-%s/[folder_name]/ במקום הורדה. השאר ריק להורדת הקובץ."

msgid "File will be named: digma-[post_type]-[start_date]-[end_date].xml"
msgstr "הקובץ ייקרא: digma-[post_type]-[start_date]-[end_date].xml"

msgid "Compress File"
msgstr "דחוס קובץ"

msgid "Compress export file (ZIP)"
msgstr "דחוס קובץ ייצוא (ZIP)"

msgid "Creates a ZIP file containing the XML export. Useful for large exports or email attachments."
msgstr "יוצר קובץ ZIP המכיל את ייצוא ה-XML. שימושי לייצואים גדולים או קבצים מצורפים למייל."

msgid "Download Export File"
msgstr "הורד קובץ ייצוא"

msgid "Export Successful!"
msgstr "ייצוא הצליח!"

msgid "Successfully exported %d posts."
msgstr "יוצאו בהצלחה %d פוסטים."

msgid "Compressed file saved to: %s"
msgstr "קובץ דחוס נשמר ב: %s"

msgid "File saved to: %s"
msgstr "קובץ נשמר ב: %s"

msgid "Download File"
msgstr "הורד קובץ"

msgid "Please select a post type to export."
msgstr "אנא בחר סוג פוסט לייצוא."

msgid "Security check failed"
msgstr "בדיקת אבטחה נכשלה"

msgid "You do not have sufficient permissions to export content."
msgstr "אין לך הרשאות מספיקות לייצא תוכן."

msgid "You do not have sufficient permissions to delete content."
msgstr "אין לך הרשאות מספיקות למחוק תוכן."

msgid "No posts found matching your criteria."
msgstr "לא נמצאו פוסטים התואמים לקריטריונים שלך."

msgid "Error: Could not save file to the specified folder."
msgstr "שגיאה: לא ניתן לשמור קובץ בתיקייה שצוינה."

msgid "Error: ZIP compression is not available on this server. ZipArchive extension is required."
msgstr "שגיאה: דחיסת ZIP אינה זמינה בשרת זה. נדרשת הרחבת ZipArchive."

msgid "Error: Could not create ZIP file. Error code: %d"
msgstr "שגיאה: לא ניתן ליצור קובץ ZIP. קוד שגיאה: %d"

msgid "Error: Could not read ZIP file content."
msgstr "שגיאה: לא ניתן לקרוא תוכן קובץ ZIP."
';

    // Write .pot file to plugin directory
    file_put_contents($languages_dir . 'cpt-export.pot', $pot_content);

    // Write Hebrew .po file to plugin directory
    file_put_contents($languages_dir . 'cpt-export-he_IL.po', $he_content);

    // Create simple .mo file for Hebrew (basic binary format)
    $mo_content = cpt_export_create_mo_file($he_content);
    file_put_contents($languages_dir . 'cpt-export-he_IL.mo', $mo_content);

    // Copy files to WordPress languages directory
    $wp_lang_dir = WP_LANG_DIR . '/plugins/';
    if (is_dir($wp_lang_dir) && is_writable($wp_lang_dir)) {
        // Copy .po and .mo files to WordPress languages directory
        copy($languages_dir . 'cpt-export-he_IL.po', $wp_lang_dir . 'cpt-export-he_IL.po');
        copy($languages_dir . 'cpt-export-he_IL.mo', $wp_lang_dir . 'cpt-export-he_IL.mo');
    }
}

/**
 * Create a basic .mo file from .po content
 * This is a simplified version that handles basic translations
 */
function cpt_export_create_mo_file($po_content)
{
    // Parse .po file to extract msgid/msgstr pairs
    $translations = array();
    $lines = explode("\n", $po_content);
    $current_msgid = '';
    $current_msgstr = '';
    $reading_msgid = false;
    $reading_msgstr = false;

    foreach ($lines as $line) {
        $line = trim($line);

        if (strpos($line, 'msgid ') === 0) {
            // Save previous translation if exists
            if ($current_msgid && $current_msgstr) {
                $translations[$current_msgid] = $current_msgstr;
            }
            $current_msgid = substr($line, 7, -1); // Remove 'msgid "' and '"'
            $current_msgstr = '';
            $reading_msgid = true;
            $reading_msgstr = false;
        } elseif (strpos($line, 'msgstr ') === 0) {
            $current_msgstr = substr($line, 8, -1); // Remove 'msgstr "' and '"'
            $reading_msgid = false;
            $reading_msgstr = true;
        } elseif (strpos($line, '"') === 0 && $reading_msgid) {
            $current_msgid .= substr($line, 1, -1); // Remove quotes
        } elseif (strpos($line, '"') === 0 && $reading_msgstr) {
            $current_msgstr .= substr($line, 1, -1); // Remove quotes
        }
    }

    // Save last translation
    if ($current_msgid && $current_msgstr) {
        $translations[$current_msgid] = $current_msgstr;
    }

    // Create basic .mo file structure
    $mo_data = '';

    // MO file header (simplified)
    $mo_data .= pack('V', 0x950412de); // Magic number
    $mo_data .= pack('V', 0); // Version
    $mo_data .= pack('V', count($translations)); // Number of strings
    $mo_data .= pack('V', 28); // Offset of table with original strings
    $mo_data .= pack('V', 28 + (count($translations) * 8)); // Offset of table with translation strings
    $mo_data .= pack('V', 0); // Hash table size
    $mo_data .= pack('V', 0); // Hash table offset

    // Build string tables
    $originals = '';
    $translations_data = '';
    $original_offsets = array();
    $translation_offsets = array();

    foreach ($translations as $original => $translation) {
        if (empty($translation))
            continue;

        $original_offsets[] = array(strlen($original), strlen($originals));
        $originals .= $original . "\0";

        $translation_offsets[] = array(strlen($translation), strlen($translations_data));
        $translations_data .= $translation . "\0";
    }

    // Write offset tables
    foreach ($original_offsets as $offset) {
        $mo_data .= pack('V', $offset[0]) . pack('V', $offset[1]);
    }

    foreach ($translation_offsets as $offset) {
        $mo_data .= pack('V', $offset[0]) . pack('V', $offset[1]);
    }

    // Write string data
    $mo_data .= $originals . $translations_data;

    return $mo_data;
}

// Generate translation files on plugin activation
register_activation_hook(__FILE__, 'cpt_export_create_translation_files');

// Add admin notice to help with translation setup
add_action('admin_notices', function () {
    if (current_user_can('manage_options')) {
        $plugin_lang_file = WP_LANG_DIR . '/plugins/cpt-export-' . get_locale() . '.mo';
        $plugin_dir_lang_file = plugin_dir_path(__FILE__) . 'languages/cpt-export-' . get_locale() . '.mo';

        if (!file_exists($plugin_lang_file) && !file_exists($plugin_dir_lang_file)) {
            echo '<div class="notice notice-info is-dismissible">';
            echo '<p><strong>CPT Export:</strong> Translation files created for ' . get_locale() . '. ';
            echo 'Files copied to: <code>' . WP_LANG_DIR . '/plugins/</code></p>';
            echo '</div>';
        }
    }
});
