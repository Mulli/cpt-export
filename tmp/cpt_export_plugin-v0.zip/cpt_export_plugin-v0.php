<?php
/**
 * Plugin Name: CPT Export Tool
 * Description: Export Custom Post Types to XML format with date range, author, and status filtering
 * Version: 1.0.0
 * Author: Your Name
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class CPT_Export_Tool {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'handle_export'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
    }
    
    public function add_admin_menu() {
        add_management_page(
            'CPT Export Tool',
            'CPT Export',
            'export',
            'cpt-export-tool',
            array($this, 'admin_page')
        );
    }
    
    public function enqueue_scripts($hook) {
        if ($hook !== 'tools_page_cpt-export-tool') {
            return;
        }
        
        wp_enqueue_script('jquery');
    }
    
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>Export Custom Post Types</h1>
            <p>When you click the button below WordPress will create an XML file for you to save to your computer.</p>
            <p>This format, which is called WordPress eXtended RSS or WXR, will contain your posts, custom fields, categories, and other content.</p>
            
            <form method="post" id="cpt-export-form">
                <?php wp_nonce_field('cpt_export_nonce', 'cpt_export_nonce'); ?>
                
                <h3>Choose what to export</h3>
                
                <table class="form-table" role="presentation">
                    <tbody>
                        <tr>
                            <th scope="row">
                                <label for="cpt_post_type">Post Type</label>
                            </th>
                            <td>
                                <select name="cpt_post_type" id="cpt_post_type">
                                    <option value="">Select a post type...</option>
                                    <?php
                                    $post_types = get_post_types(array('public' => true), 'objects');
                                    foreach ($post_types as $post_type) {
                                        if ($post_type->name !== 'attachment') {
                                            echo '<option value="' . esc_attr($post_type->name) . '">' . esc_html($post_type->label) . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                                <p class="description">Select the post type you want to export.</p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <label for="cpt_author">Author</label>
                            </th>
                            <td>
                                <select name="cpt_author" id="cpt_author">
                                    <option value="">All authors</option>
                                    <?php
                                    $authors = get_users(array(
                                        'capability' => 'edit_posts',
                                        'fields' => array('ID', 'display_name')
                                    ));
                                    foreach ($authors as $author) {
                                        echo '<option value="' . esc_attr($author->ID) . '">' . esc_html($author->display_name) . '</option>';
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <label for="cpt_status">Status</label>
                            </th>
                            <td>
                                <select name="cpt_status" id="cpt_status">
                                    <option value="">All statuses</option>
                                    <option value="published">Published</option>
                                    <option value="draft">Draft</option>
                                    <option value="private">Private</option>
                                    <option value="pending">Pending Review</option>
                                    <option value="future">Scheduled</option>
                                </select>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">Date Range</th>
                            <td>
                                <fieldset>
                                    <legend class="screen-reader-text">Date Range</legend>
                                    <label for="cpt_start_date">
                                        Start Date: 
                                        <input type="date" name="cpt_start_date" id="cpt_start_date">
                                    </label>
                                    <br><br>
                                    <label for="cpt_end_date">
                                        End Date: 
                                        <input type="date" name="cpt_end_date" id="cpt_end_date">
                                    </label>
                                    <p class="description">Leave blank to export all dates.</p>
                                </fieldset>
                            </td>
                        </tr>
                    </tbody>
                </table>
                
                <p class="submit">
                    <input type="submit" name="submit" id="submit" class="button button-primary" value="Download Export File">
                </p>
            </form>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            $('#cpt-export-form').on('submit', function(e) {
                var postType = $('#cpt_post_type').val();
                if (!postType) {
                    e.preventDefault();
                    alert('Please select a post type to export.');
                    return false;
                }
            });
        });
        </script>
        <?php
    }
    
    public function handle_export() {
        if (!isset($_POST['submit']) || !isset($_POST['cpt_export_nonce'])) {
            return;
        }
        
        if (!wp_verify_nonce($_POST['cpt_export_nonce'], 'cpt_export_nonce')) {
            wp_die('Security check failed');
        }
        
        if (!current_user_can('export')) {
            wp_die('You do not have sufficient permissions to export content.');
        }
        
        $post_type = sanitize_text_field($_POST['cpt_post_type']);
        $author = sanitize_text_field($_POST['cpt_author']);
        $status = sanitize_text_field($_POST['cpt_status']);
        $start_date = sanitize_text_field($_POST['cpt_start_date']);
        $end_date = sanitize_text_field($_POST['cpt_end_date']);
        
        if (empty($post_type)) {
            wp_die('Please select a post type to export.');
        }
        
        $this->export_cpt($post_type, $author, $status, $start_date, $end_date);
    }
    
    public function export_cpt($post_type, $author = '', $status = '', $start_date = '', $end_date = '') {
        // Build query arguments
        $args = array(
            'post_type' => $post_type,
            'posts_per_page' => -1,
            'post_status' => $status ? $status : array('publish', 'draft', 'private', 'pending', 'future'),
            'orderby' => 'date',
            'order' => 'DESC'
        );
        
        if (!empty($author)) {
            $args['author'] = $author;
        }
        
        // Add date query if dates are provided
        if (!empty($start_date) || !empty($end_date)) {
            $date_query = array();
            
            if (!empty($start_date)) {
                $date_query['after'] = $start_date;
            }
            
            if (!empty($end_date)) {
                $date_query['before'] = $end_date;
            }
            
            $args['date_query'] = array($date_query);
        }
        
        $posts = get_posts($args);
        
        if (empty($posts)) {
            wp_die('No posts found matching your criteria.');
        }
        
        // Generate filename
        $filename = sanitize_file_name($post_type . '-export-' . date('Y-m-d') . '.xml');
        
        // Set headers for download
        header('Content-Description: File Transfer');
        header('Content-Disposition: attachment; filename=' . $filename);
        header('Content-Type: text/xml; charset=' . get_option('blog_charset'));
        
        // Generate XML
        echo $this->generate_xml($posts, $post_type);
        exit;
    }
    
    public function generate_xml($posts, $post_type) {
        $sitename = sanitize_key(get_bloginfo('name'));
        if (!empty($sitename)) {
            $sitename .= '.';
        }
        $date = date('Y-m-d H:i');
        
        $xml = '<?xml version="1.0" encoding="' . get_bloginfo('charset') . "\" ?>\n";
        $xml .= "<!-- This is a WordPress eXtended RSS file generated by the CPT Export Tool as an export of your site. -->\n";
        $xml .= "<!-- It contains information about your site's posts, pages, comments, categories, and other content. -->\n";
        $xml .= "<!-- You may use this file to transfer that content from one site to another. -->\n";
        $xml .= "<!-- This file is not intended to serve as a complete backup of your site. -->\n\n";
        
        $xml .= '<rss version="2.0"' . "\n";
        $xml .= "\t" . 'xmlns:excerpt="http://wordpress.org/export/1.2/excerpt/"' . "\n";
        $xml .= "\t" . 'xmlns:content="http://purl.org/rss/1.0/modules/content/"' . "\n";
        $xml .= "\t" . 'xmlns:wfw="http://wellformedweb.org/CommentAPI/"' . "\n";
        $xml .= "\t" . 'xmlns:dc="http://purl.org/dc/elements/1.1/"' . "\n";
        $xml .= "\t" . 'xmlns:wp="http://wordpress.org/export/1.2/"' . "\n";
        $xml .= ">\n\n";
        
        $xml .= "<channel>\n";
        $xml .= "\t<title>" . esc_html(get_bloginfo('name')) . "</title>\n";
        $xml .= "\t<link>" . esc_url(get_bloginfo('url')) . "</link>\n";
        $xml .= "\t<description>" . esc_html(get_bloginfo('description')) . "</description>\n";
        $xml .= "\t<pubDate>" . date('D, d M Y H:i:s +0000') . "</pubDate>\n";
        $xml .= "\t<language>" . esc_html(get_bloginfo('language')) . "</language>\n";
        $xml .= "\t<wp:wxr_version>1.2</wp:wxr_version>\n";
        $xml .= "\t<wp:base_site_url>" . esc_url(get_option('home')) . "</wp:base_site_url>\n";
        $xml .= "\t<wp:base_blog_url>" . esc_url(get_bloginfo('url')) . "</wp:base_blog_url>\n\n";
        
        // Export posts
        foreach ($posts as $post) {
            $xml .= $this->generate_post_xml($post);
        }
        
        $xml .= "</channel>\n";
        $xml .= "</rss>\n";
        
        return $xml;
    }
    
    public function generate_post_xml($post) {
        $xml = "\t<item>\n";
        $xml .= "\t\t<title>" . $this->wxr_cdata($post->post_title) . "</title>\n";
        $xml .= "\t\t<link>" . esc_url(get_permalink($post)) . "</link>\n";
        $xml .= "\t\t<pubDate>" . mysql2date('D, d M Y H:i:s +0000', $post->post_date, false) . "</pubDate>\n";
        $xml .= "\t\t<dc:creator>" . $this->wxr_cdata(get_the_author_meta('login', $post->post_author)) . "</dc:creator>\n";
        $xml .= "\t\t<guid isPermaLink=\"false\">" . esc_url(get_the_guid($post->ID)) . "</guid>\n";
        $xml .= "\t\t<description></description>\n";
        $xml .= "\t\t<content:encoded>" . $this->wxr_cdata($post->post_content) . "</content:encoded>\n";
        $xml .= "\t\t<excerpt:encoded>" . $this->wxr_cdata($post->post_excerpt) . "</excerpt:encoded>\n";
        $xml .= "\t\t<wp:post_id>" . intval($post->ID) . "</wp:post_id>\n";
        $xml .= "\t\t<wp:post_date>" . $this->wxr_cdata($post->post_date) . "</wp:post_date>\n";
        $xml .= "\t\t<wp:post_date_gmt>" . $this->wxr_cdata($post->post_date_gmt) . "</wp:post_date_gmt>\n";
        $xml .= "\t\t<wp:comment_status>" . $this->wxr_cdata($post->comment_status) . "</wp:comment_status>\n";
        $xml .= "\t\t<wp:ping_status>" . $this->wxr_cdata($post->ping_status) . "</wp:ping_status>\n";
        $xml .= "\t\t<wp:post_name>" . $this->wxr_cdata($post->post_name) . "</wp:post_name>\n";
        $xml .= "\t\t<wp:status>" . $this->wxr_cdata($post->post_status) . "</wp:status>\n";
        $xml .= "\t\t<wp:post_parent>" . intval($post->post_parent) . "</wp:post_parent>\n";
        $xml .= "\t\t<wp:menu_order>" . intval($post->menu_order) . "</wp:menu_order>\n";
        $xml .= "\t\t<wp:post_type>" . $this->wxr_cdata($post->post_type) . "</wp:post_type>\n";
        $xml .= "\t\t<wp:post_password>" . $this->wxr_cdata($post->post_password) . "</wp:post_password>\n";
        $xml .= "\t\t<wp:is_sticky>" . intval($post->post_type == 'post' && is_sticky($post->ID)) . "</wp:is_sticky>\n";
        
        // Export custom fields
        $custom_fields = get_post_custom($post->ID);
        if (!empty($custom_fields)) {
            foreach ($custom_fields as $key => $values) {
                // Skip private fields and WordPress internal fields
                if (substr($key, 0, 1) == '_') {
                    continue;
                }
                
                foreach ($values as $value) {
                    $xml .= "\t\t<wp:postmeta>\n";
                    $xml .= "\t\t\t<wp:meta_key>" . $this->wxr_cdata($key) . "</wp:meta_key>\n";
                    $xml .= "\t\t\t<wp:meta_value>" . $this->wxr_cdata($value) . "</wp:meta_value>\n";
                    $xml .= "\t\t</wp:postmeta>\n";
                }
            }
        }
        
        // Export taxonomies
        $taxonomies = get_object_taxonomies($post->post_type);
        if (!empty($taxonomies)) {
            foreach ($taxonomies as $taxonomy) {
                $terms = get_the_terms($post->ID, $taxonomy);
                if (!empty($terms) && !is_wp_error($terms)) {
                    foreach ($terms as $term) {
                        $xml .= "\t\t<category domain=\"" . esc_attr($taxonomy) . "\" nicename=\"" . esc_attr($term->slug) . "\">" . $this->wxr_cdata($term->name) . "</category>\n";
                    }
                }
            }
        }
        
        $xml .= "\t</item>\n\n";
        
        return $xml;
    }
    
    private function wxr_cdata($str) {
        if (!seems_utf8($str)) {
            $str = utf8_encode($str);
        }
        
        $str = '<![CDATA[' . str_replace(']]>', ']]]]><![CDATA[>', $str) . ']]>';
        
        return $str;
    }
}

// Initialize the plugin
new CPT_Export_Tool();
?>